## Module <odoo_website_helpdesk>

#### 30.10.2024
#### Version 18.0.1.0.0
#### ADD

- Initial commit for Website Helpdesk Support Ticket Management

#### 12.02.2025
#### Version 18.0.1.0.1
##### UPDT
-A new contact record is created upon form submission.

#### 05.07.2025
#### Version 18.0.1.0.2
##### FIX
- Tickets created was not visible for the user.