To use this module, you need to:

- Go to Knowledge menu
- Click on Categories to create the document's category you need with
  the template
- Click on Pages to create pages and select the previous category to use
  the template
